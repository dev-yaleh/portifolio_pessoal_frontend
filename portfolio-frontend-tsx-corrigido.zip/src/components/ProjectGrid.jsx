import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import ProjectCard from "./ProjectCard";

export default function ProjectsGrid({ projects, categories, onOpenModal }) {
  const [selectedCategory, setSelectedCategory] = useState("all");

  const filteredProjects =
    selectedCategory === "all"
      ? projects
          : projects.filter((p) => String(p.categoria?.id) === selectedCategory);

  return (
    <div className="projects-grid">
      <div className="projects-filters">
        <button
          type="button"
          className={selectedCategory === "all" ? "active" : ""}
          onClick={() => setSelectedCategory("all")}
        >
          Todos
        </button>

        {categories?.map((category) => (
          <button
            key={category.id}
            type="button"
            className={selectedCategory === category.id ? "active" : ""}
            onClick={() => setSelectedCategory(category.id)}
          >
            {category.name}
          </button>
        ))}
      </div>

      <motion.div layout className="projects-list">
        <AnimatePresence mode="popLayout">
          {filteredProjects?.map((project) => (
            <ProjectCard
              key={project.id}
              projeto={project}
              onOpen={onOpenModal}
            />
          ))}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
