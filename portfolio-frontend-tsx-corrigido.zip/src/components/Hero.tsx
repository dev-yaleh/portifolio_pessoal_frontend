import { useEffect, useState, type SVGProps } from "react";
import { motion, type Variants } from "motion/react";

type IconProps = SVGProps<SVGSVGElement>;

const Terminal = (props: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>
    <polyline points="4 17 10 11 4 5" />
    <line x1="12" y1="19" x2="20" y2="19" />
  </svg>
);

const ArrowRight = (props: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>
    <line x1="5" y1="12" x2="19" y2="12" />
    <polyline points="12 5 19 12 12 19" />
  </svg>
);

const Activity = (props: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>
    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
  </svg>
);

const roles = [
  "Full Stack Engineer",
  "UI/UX Specialist",
  "React & Node.js Developer",
];

export default function HeroSection({ apiOnline = true }: { apiOnline?: boolean }) {
  const [currentRoleIndex, setCurrentRoleIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const currentRole = roles[currentRoleIndex];
    let typingSpeed = isDeleting ? 40 : 80;

    if (!isDeleting && displayedText === currentRole) {
      typingSpeed = 2000;
    } else if (isDeleting && displayedText === "") {
      setIsDeleting(false);
      setCurrentRoleIndex((prev) => (prev + 1) % roles.length);
      typingSpeed = 500;
    }

    const timer = setTimeout(() => {
      setDisplayedText((prev) =>
        isDeleting
          ? currentRole.substring(0, prev.length - 1)
          : currentRole.substring(0, prev.length + 1)
      );

      if (!isDeleting && displayedText === currentRole) {
        setIsDeleting(true);
      }
    }, typingSpeed);

    return () => clearTimeout(timer);
  }, [displayedText, isDeleting, currentRoleIndex]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants: Variants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: "spring", damping: 20, stiffness: 100 },
    },
  };

  return (
    <section className="relative overflow-hidden bg-slate-950 text-white">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(59,130,246,0.18),transparent_40%)]" />

      <motion.div
        className="relative mx-auto flex min-h-[80vh] max-w-7xl items-center px-6 py-20 md:px-10"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <div className="max-w-3xl">
          <motion.div variants={itemVariants} className="mb-6 inline-flex items-center">
            <span
              className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm font-medium ${
                apiOnline
                  ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
                  : "border-red-500/30 bg-red-500/10 text-red-300"
              }`}
            >
              <Activity className="h-4 w-4" />
              {apiOnline ? "API online" : "API offline"}
            </span>
          </motion.div>

          <motion.h1
            variants={itemVariants}
            className="text-4xl font-black leading-tight tracking-tight sm:text-5xl lg:text-7xl"
          >
            I build bold digital experiences
            <span className="mt-3 block bg-linear-to-r from-sky-400 via-blue-500 to-violet-500 bg-clip-text text-transparent">
              {displayedText}
              <span className="ml-1 inline-block h-[0.9em] w-0.5 animate-pulse bg-current align-middle" />
            </span>
          </motion.h1>

          <motion.p
            variants={itemVariants}
            className="mt-6 max-w-2xl text-lg text-slate-300 md:text-xl"
          >
            I&apos;m a full-stack developer focused on crafting performant interfaces, reliable systems,
            and user experiences that feel effortless from the first click to the final deployment.
          </motion.p>

          <motion.div variants={itemVariants} className="mt-8 flex flex-wrap items-center gap-4">
            <a
              href="#projects"
              className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-semibold text-slate-950 transition hover:-translate-y-0.5 hover:bg-slate-200"
            >
              View projects
              <ArrowRight className="h-4 w-4" />
            </a>

            <a
              href="#contact"
              className="inline-flex items-center gap-2 rounded-full border border-slate-700 bg-slate-900/70 px-6 py-3 text-sm font-semibold text-white transition hover:border-slate-500 hover:bg-slate-800"
            >
              Let&apos;s talk
            </a>
          </motion.div>

          <motion.div variants={itemVariants} className="mt-10 flex items-center gap-3 text-sm text-slate-300">
            <div className="flex items-center gap-2 rounded-full border border-slate-700 bg-slate-900/50 px-3 py-2">
              <Terminal className="h-4 w-4 text-sky-400" />
              Available for freelance projects
            </div>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
}
