import type { Projeto } from '../types';
import { motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import type { MouseEvent } from 'react';

interface ProjectCardProps {
  projeto: Projeto;
  onOpen: (projeto: Projeto) => void;
}

export default function ProjectCard({ projeto, onOpen }: ProjectCardProps) {
  const cover = projeto.images?.[0];
  const pointerX = useMotionValue(.5);
  const pointerY = useMotionValue(.5);
  const rotateX = useSpring(useTransform(pointerY, [0, 1], [5, -5]), { stiffness: 180, damping: 22 });
  const rotateY = useSpring(useTransform(pointerX, [0, 1], [-5, 5]), { stiffness: 180, damping: 22 });

  function trackPointer(event: MouseEvent<HTMLButtonElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    pointerX.set((event.clientX - rect.left) / rect.width);
    pointerY.set((event.clientY - rect.top) / rect.height);
    event.currentTarget.style.setProperty('--glow-x', `${event.clientX - rect.left}px`);
    event.currentTarget.style.setProperty('--glow-y', `${event.clientY - rect.top}px`);
  }

  return (
    <motion.button
      type="button"
      onClick={() => onOpen(projeto)}
      onMouseMove={trackPointer}
      onMouseLeave={() => { pointerX.set(.5); pointerY.set(.5); }}
      style={{ rotateX, rotateY, transformPerspective: 900 }}
      whileTap={{ scale: .985 }}
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: .15 }}
      transition={{ duration: .45 }}
      className="project-glow group relative text-left glass-card rounded-2xl border border-borderCol overflow-hidden hover:border-brandBlue/50 transition-colors duration-300 focus-ring"
    >
      <div className="h-44 bg-darkBg overflow-hidden relative">
        {cover ? <img src={cover} alt={projeto.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" onError={(event) => { event.currentTarget.src = 'https://placehold.co/600x300/070c18/00a2ff?text=Projeto'; }} /> : <div className="w-full h-full flex items-center justify-center text-slate-600 text-sm"><i className="fa-solid fa-image text-2xl" /></div>}
        {projeto.featured && <span className="absolute top-3 right-3 px-2.5 py-1 rounded-lg bg-brandOrange/90 text-white text-[10px] font-bold uppercase tracking-wider">Destaque</span>}
        {projeto.categoria?.name && <span className="absolute bottom-3 left-3 px-2.5 py-1 rounded-lg bg-darkBg/80 border border-borderCol text-brandBlue text-[10px] font-semibold uppercase tracking-wider">{projeto.categoria.name}</span>}
      </div>
      <div className="p-5 space-y-3">
        <h3 className="font-bold text-white group-hover:text-brandBlue transition-colors">{projeto.name}</h3>
        <p className="text-sm text-slate-400 line-clamp-2 font-light">{projeto.description}</p>
        {!!projeto.techs?.length && <div className="flex flex-wrap gap-1.5 pt-1">{projeto.techs.slice(0, 4).map((tech) => <span key={tech} className="text-[10px] px-2 py-1 rounded-lg bg-brandBlue/10 text-brandBlue border border-brandBlue/20 font-semibold">{tech}</span>)}</div>}
        <div className="flex items-center justify-between pt-2 text-xs text-slate-500"><span className="flex items-center gap-1.5"><i className="fa-solid fa-eye" />{projeto.views ?? 0} visualizações</span><span className="text-brandBlue font-semibold group-hover:translate-x-1 transition-transform">Ver detalhes <i className="fa-solid fa-arrow-right ml-1" /></span></div>
      </div>
    </motion.button>
  );
}
